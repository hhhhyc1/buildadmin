-- -----------------------------
-- MySQL Data Transfer
--
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : badmin
--
-- Part : #1
-- Date : 2023-08-16 15:44:15
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `ba_test`
-- -----------------------------
DROP TABLE IF EXISTS `ba_test`;
CREATE TABLE `ba_test` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态:0=禁用,1=启用',
  `create_time` bigint(20) unsigned DEFAULT NULL COMMENT '创建时间',
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户',
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '城市选择',
  `column1` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '字段1',
  `column2` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '字段2',
  `image` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '图片',
  `datetime` datetime DEFAULT NULL COMMENT '时间日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='测试';

-- -----------------------------
-- Records of `ba_test`
-- -----------------------------
INSERT INTO `ba_test` VALUES (1, 1, 1691638743, 1, '19,20,23', '11', '', '', NULL);
INSERT INTO `ba_test` VALUES (2, 0, 1692171670, 1, '19,20,21', '1', '2', '/storage/default/20230816/11f0a2becd26ac86963ccf897a94ab61bbdd2e148.jpg', '2023-08-31 00:00:00');
